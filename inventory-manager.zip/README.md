# Inventory Manager

在庫・使用量管理システム (React + TypeScript + Vite)

## 開発サーバー

```bash
npm install
npm run dev
```

## 本番ビルド

```bash
npm run build
```

## GitHub へのアップロード

1. GitHub で新しいリポジトリを作成  
2. ターミナルで次を実行

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<REPO_NAME>.git
git push -u origin main
```

`<YOUR_USERNAME>` と `<REPO_NAME>` を置き換えてください。