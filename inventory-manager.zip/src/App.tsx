import InventoryManager from "./components/InventoryManager";

export default function App() {
  return <InventoryManager />;
}